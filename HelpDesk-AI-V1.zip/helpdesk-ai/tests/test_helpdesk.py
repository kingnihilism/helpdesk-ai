from pathlib import Path

from helpdesk_ai import HelpDeskEngine, load_tickets, redact_sensitive, save_ticket


def test_security_ticket_is_critical():
    result = HelpDeskEngine().analyze("I clicked a phishing link and entered my password")
    assert result.category == "Security Incident"
    assert result.priority == "Critical"
    assert result.security_flag is True
    assert result.articles[0]["id"] == "KB-SEC-001"


def test_network_ticket_retrieves_network_article():
    result = HelpDeskEngine().analyze("Wi-Fi connects but websites do not load")
    assert result.category == "Network"
    assert result.articles[0]["id"] == "KB-NET-001"


def test_sensitive_values_are_redacted():
    text = redact_sensitive("password: SuperSecret123 token=abc123")
    assert "SuperSecret123" not in text
    assert "abc123" not in text
    assert text.count("[REDACTED]") == 2


def test_ticket_can_be_saved(tmp_path: Path):
    database = tmp_path / "test.db"
    result = HelpDeskEngine().analyze("My account is locked")
    ticket_id = save_ticket(database, result, "Resolved", "Identity verified")
    history = load_tickets(database)
    assert ticket_id == 1
    assert len(history) == 1
    assert history.iloc[0]["status"] == "Resolved"
